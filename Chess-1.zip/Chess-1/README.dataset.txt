# Chess > 2023-11-28 4:00pm
https://universe.roboflow.com/chess-bjkwh/chess-4jvm8

Provided by a Roboflow user
License: MIT

